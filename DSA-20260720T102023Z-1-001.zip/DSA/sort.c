#include <stdio.h>

int sort(int arr[], int size)
{
    int temp;
    int n = size;
    printf("%d\n", n);

    int i, j;
    printf("The elemnets before sorting\n");
    for (i = 0; i < n; i++)
    {
        printf("%d, ", arr[i]);
    }


    for (i = 0; i < n; i++)
    {
        printf("%d",i);
        for (j = i + 1; j < n; j++)
        {
            printf("%d",j);
            if (arr[i] > arr[j])
            {
                arr[i]=temp;
                arr[i] = arr[i+1];
                arr[i+1] = temp;
            }
            else{
                j++;
            }
        }
        
       
    }
    printf("\nThe elements after sorting\n");
    for(i = 0; i < n; i++)
    {
        printf("%d\t", arr[i]);
    }
}
int main()
{
    int array[5] = {4, -1, 2, -3, 4};
    int size = sizeof(array) / sizeof(array[0]);
    printf("%d\n", size);
    sort(array, size);
    return 0;
}
