#include <stdio.h>
/*
 QUESTION FOR SRISHTI SINGH, HOUSE NUMBER 84, SHAHAPUR CHHAVANI
1. Create 2 variables, VAR1 of type int, VAR2 of type double
2. Assign 100 to var1 and 34.2 to var2
3. print the values
4. print the address of these 2 variables
5. create a pointer variable say, pvar1 and point it to of var1
6. create a pointer varialbe say, pvar2 and point it to var2
7. pint valures of these pointer variables
8. print address of thse pointer varialbes
9. update var 1 to 200 using pvar1
10. update var 2 to 55.5 using pvar2
11. print the result of var1 and var2
13. print the result of dereference of pvar1 and pvar2
*/
int main()
{
    int var1;
    double var2;
    var1 = 100;
    var2 = 34.2;
    printf("Value of val1 - %d\n", var1);
    printf("Value of val2 - %.1f\n", var2);
    printf("address of var1 - %x\n", &var1);
    printf("addres of var2 - %x\n", &var2);
    int *pvar1 = &var1;
    double *pvar2 = &var2;
    printf("value of var1 - %d\n", *pvar1);
    printf("Value of var2 - %f\n", *pvar2);
    *pvar1 = 200;
    *pvar2 = 55.5;
    printf("Value of var1 is %d\n", *pvar1);
    printf("Value of var2 is %f\n", *pvar2);

    return 0;
}